package t24pham.cs456.a2.common;

public interface IFileSender {

  void send();

}
